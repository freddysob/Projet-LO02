
public class Inverseur extends Carte {
	
	public Inverseur(NumeroCarte num,TypCarte typ){
		super(num, typ);
	}
	
	public void appliquerPouvoir() {
	   
	 }
	
	public static void main(String[] args ) {
    	
    }
}