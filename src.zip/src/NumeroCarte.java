//import com.modeliosoft.modelio.javadesigner.annotations.objid;

//@objid ("946b565c-06c2-4ee5-a3aa-64bbd721464d")
public enum NumeroCarte {
    _J,
    _1,
    _2,
    _3,
    _4,
    _5,
    _6,
    _7,
    _8,
    _9,
    _10,
    _V,
    _D,
    _R;
}