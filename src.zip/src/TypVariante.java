//import com.modeliosoft.modelio.javadesigner.annotations.objid;

//@objid ("7e200235-cc1d-48cc-8d21-fdab8e7bc036")
public enum TypVariante {
    Minimale,
    Monclar,
    Variante_1,
    Carte_et_Maou,
    Des_Ulis,
    Variante_4,
    Variante_5,
    Variante_6,
    Variante_Courte_Amicale,
    Man_et_resta;
}

