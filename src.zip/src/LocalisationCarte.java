//import com.modeliosoft.modelio.javadesigner.annotations.objid;

// @objid ("b8fd996a-e5ca-4bb3-b585-6fe9809a1171")
public enum LocalisationCarte {
    MainJoueur,
    Tatamis,
    Pioche;
}
