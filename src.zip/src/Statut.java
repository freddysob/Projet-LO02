//import com.modeliosoft.modelio.javadesigner.annotations.objid;

//@objid ("98baa5ff-51cd-449a-b6e0-a8987401487e")
public enum Statut {
    Encours,
    Terminee;
}
