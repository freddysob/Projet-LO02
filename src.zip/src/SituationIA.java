//import com.modeliosoft.modelio.javadesigner.annotations.objid;

//@objid ("3f141fc2-2d20-4e7b-9a5b-67bd4847a3d3")
public enum SituationIA {
    Normale,
    _1JoueurAvance,
    _2JoueursAvances;
}
