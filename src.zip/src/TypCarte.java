// import com.modeliosoft.modelio.javadesigner.annotations.objid;

//@objid ("2ba5147a-efe2-4789-92ee-743e704a43fe")
public enum TypCarte {
    Coeur,
    Trefle,
    Pique,
    Carreau,
    JR,
    JN;
}
